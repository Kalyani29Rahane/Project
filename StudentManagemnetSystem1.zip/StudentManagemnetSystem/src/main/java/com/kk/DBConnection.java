package com.kk;
import java.sql.*;
public class DBConnection {
	
	    public static Connection getConnection() throws Exception {
	        String url = "jdbc:mysql://localhost:3306/project";
	        String username = "root"; //  MySQL username
	        String password = "Wj28@krhps"; //  MySQL password

	        Class.forName("com.mysql.cj.jdbc.Driver");
	        return DriverManager.getConnection(url, username, password);
	    }
	}



