//package com.kk;
//**** only refer for study*****
//public class Information {
//Information about the whole project:

//Student Management System (Java, JDBC, MySQL) — Built a CRUD-based Java application to manage student
//records using JDBC and MySQL. Applied core Java OOP concepts, exception handling, and structured
//database connectivity.

//Tech Stack: Java, JDBC, MySQL

//Description:
//Developed a Java-based command-line application to manage student records (Add, View, Update, Delete)
//using JDBC for database connectivity. The project demonstrates strong knowledge of OOP principles,
//exception handling, and database operations.
//
//Key Features:
//	1] Performed CRUD operations using JDBC
//
//	2] Applied OOP concepts: Encapsulation and Class Structure
//
//	3] Implemented error handling with try-catch and proper user input validation
//
//	4] Used MySQL for persistent storage
//
//	*** How to Explain in the Interview***
//	🔹 Q: What is your project about?
//	Answer:
//	My project is a Student Management System, a console-based application developed in Core Java.
//It connects to a MySQL database using JDBC. The application can add, view, update, and delete 
//student records. It helped me understand real-time CRUD operations and apply OOP concepts practically.
//
//	🔹 Q: What technologies did you use?
//	Answer:
//	Java (Core Java, OOP, Exception Handling)
//
//	JDBC for database connectivity
//
//	MySQL for storing student data
//
//	🔹 Q: How is JDBC used in your project?
//	Answer:
//	I used JDBC API to connect my Java program to MySQL. It allowed me to:
//
//	Establish a connection using DriverManager
//
//	Write SQL queries using PreparedStatement and Statement
//
//	Fetch results using ResultSet
//
//	Handle exceptions and close connections properly
//
//	🔹 Q: Which OOPs concepts are implemented in your project?
//	Answer:
//
//	Encapsulation: Student data is handled via private fields and public getters/setters in the Student class.
//
//	Abstraction: Database logic is hidden inside the StudentDAO class.
//
//	Class and Object: I created reusable classes and objects to organize code logically.
//
//	🔹 Q: What challenges did you face and how did you solve them?
//	Answer:
//	One challenge was handling SQL exceptions and managing connections properly. I used try-catch-finally
//blocks and separated the DB logic into a separate class (DBConnection) for reusability and cleaner code.
//
//	✅ Tips for Adding to Resume (Sample Resume Line):
//	🧩 Student Management System (Java, JDBC, MySQL) — Built a CRUD-based Java application to manage 
//student records using JDBC and MySQL. Applied core Java OOP concepts, exception handling, and structured
//database connectivity.
//
