package com.kk;

	import java.sql.*;
	import java.util.*;

	public class StudentDAO {

	    public void addStudent(Student student) throws Exception {
	        Connection conn = DBConnection.getConnection();
	        String query = "INSERT INTO students(name, marks, course) VALUES (?, ?, ?)";
	        PreparedStatement stmt = conn.prepareStatement(query);
	        stmt.setString(1, student.getName());
	        stmt.setInt(2, student.getMarks());
	        stmt.setString(3, student.getCourse());
	        stmt.executeUpdate();
	        conn.close();
	    }

	    public List<Student> getAllStudents() throws Exception {
	        List<Student> list = new ArrayList<>();
	        Connection conn = DBConnection.getConnection();
	        String query = "SELECT * FROM students";
	        Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery(query);
	        while (rs.next()) {
	            Student s = new Student();
	            s.setId(rs.getInt("id"));
	            s.setName(rs.getString("name"));
	            s.setMarks(rs.getInt("marks"));
	            s.setCourse(rs.getString("course"));
	            list.add(s);
	        }
	        conn.close();
	        return list;
	    }

	    public void updateStudent(Student student) throws Exception {
	        Connection conn = DBConnection.getConnection();
	        String query = "UPDATE students SET name=?, Marks=?, course=? WHERE id=?";
	        PreparedStatement stmt = conn.prepareStatement(query);
	        stmt.setString(1, student.getName());
	        stmt.setInt(2, student.getMarks());
	        stmt.setString(3, student.getCourse());
	        stmt.setInt(4, student.getId());
	        stmt.executeUpdate();
	        conn.close();
	    }

	    public void deleteStudent(int id) throws Exception {
	        Connection conn = DBConnection.getConnection();
	        String query = "DELETE FROM students WHERE id=?";
	        PreparedStatement stmt = conn.prepareStatement(query);
	        stmt.setInt(1, id);
	        stmt.executeUpdate();
	        conn.close();
	    }
	}


