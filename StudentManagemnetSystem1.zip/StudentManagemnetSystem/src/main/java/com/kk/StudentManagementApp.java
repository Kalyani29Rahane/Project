package com.kk;

import java.util.*;

public class StudentManagementApp {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentDAO dao = new StudentDAO();

        while (true) {
            System.out.println("\n=== Student Management System ===");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");

            System.out.print("Choose option: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        Student s = new Student();
                        System.out.print("Enter name: ");
                        s.setName(sc.next());
                        System.out.print("Enter Marks: ");
                        s.setMarks(sc.nextInt());
                        System.out.print("Enter course: ");
                        s.setCourse(sc.next());
                        dao.addStudent(s);
                        System.out.println("Student added.");
                        break;

                    case 2:
                        List<Student> list = dao.getAllStudents();
                        for (Student st : list) {
                            System.out.println(st.getId() + " " + st.getName() + " " + st.getMarks() + " " + st.getCourse());
                        }
                        break;

                    case 3:
                        Student s1 = new Student();
                        System.out.print("Enter ID to update: ");
                        s1.setId(sc.nextInt());
                        System.out.print("Enter new name: ");
                        s1.setName(sc.next());
                        System.out.print("Enter new Marks: ");
                        s1.setMarks(sc.nextInt());
                        System.out.print("Enter new course: ");
                        s1.setCourse(sc.next());
                        dao.updateStudent(s1);
                        System.out.println("Student updated.");
                        break;

                    case 4:
                        System.out.print("Enter ID to delete: ");
                        int id = sc.nextInt();
                        dao.deleteStudent(id);
                        System.out.println("Student deleted.");
                        break;

                    case 5:
                        System.exit(0);

                    default:
                        System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}

